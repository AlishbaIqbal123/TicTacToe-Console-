#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>

using namespace std;

const int BOARD_SIZE = 3;
const char HUMAN = 'X';
const char COMPUTER = 'O';
const char EMPTY = ' ';

void printBoard(const vector<vector<char>>& board);
bool isMoveValid(const vector<vector<char>>& board, int row, int col);
bool isBoardFull(const vector<vector<char>>& board);
bool checkWin(const vector<vector<char>>& board, char player);
void humanMove(vector<vector<char>>& board);
void computerMove(vector<vector<char>>& board);

int main() {
    vector<vector<char>> board(BOARD_SIZE, vector<char>(BOARD_SIZE, EMPTY));
    srand(time(0));
    
    cout << "Welcome to Tic Tac Toe!\nYou are " << HUMAN << " and the computer is " << COMPUTER << endl;
    printBoard(board);
    
    char currentPlayer = HUMAN;
    
    while (true) {
        if (currentPlayer == HUMAN) humanMove(board);
        else computerMove(board);
        
        printBoard(board);
        
        if (checkWin(board, currentPlayer)) {
            cout << (currentPlayer == HUMAN ? "You win!" : "Computer wins!") << endl;
            break;
        }
        
        if (isBoardFull(board)) {
            cout << "It's a tie!" << endl;
            break;
        }
        
        currentPlayer = (currentPlayer == HUMAN) ? COMPUTER : HUMAN;
    }
    return 0;
}

void printBoard(const vector<vector<char>>& board) {
    cout << "\n";
    for (int i = 0; i < BOARD_SIZE; ++i) {
        cout << " ";
        for (int j = 0; j < BOARD_SIZE; ++j) {
            cout << board[i][j];
            if (j < BOARD_SIZE - 1) cout << " | ";
        }
        cout << "\n";
        if (i < BOARD_SIZE - 1) cout << "-----------\n";
    }
    cout << "\n";
}

bool isMoveValid(const vector<vector<char>>& board, int row, int col) {
    return (row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE && board[row][col] == EMPTY);
}

bool isBoardFull(const vector<vector<char>>& board) {
    for (const auto& row : board)
        for (char cell : row)
            if (cell == EMPTY) return false;
    return true;
}

bool checkWin(const vector<vector<char>>& board, char player) {
    for (int i = 0; i < BOARD_SIZE; ++i) {
        if (board[i][0] == player && board[i][1] == player && board[i][2] == player) return true;
        if (board[0][i] == player && board[1][i] == player && board[2][i] == player) return true;
    }
    return (board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
           (board[0][2] == player && board[1][1] == player && board[2][0] == player);
}

void humanMove(vector<vector<char>>& board) {
    int row, col;
    while (true) {
        cout << "Enter your move (row and column, 1-3): ";
        cin >> row >> col;
        row--; col--;
        if (isMoveValid(board, row, col)) {
            board[row][col] = HUMAN;
            break;
        }
        cout << "Invalid move. Try again.\n";
    }
}

void computerMove(vector<vector<char>>& board) {
    cout << "Computer's turn...\n";
    
    // Check for winning move
    for (int i = 0; i < BOARD_SIZE; ++i)
        for (int j = 0; j < BOARD_SIZE; ++j)
            if (board[i][j] == EMPTY) {
                board[i][j] = COMPUTER;
                if (checkWin(board, COMPUTER)) return;
                board[i][j] = EMPTY;
            }
    
    // Block human's winning move
    for (int i = 0; i < BOARD_SIZE; ++i)
        for (int j = 0; j < BOARD_SIZE; ++j)
            if (board[i][j] == EMPTY) {
                board[i][j] = HUMAN;
                if (checkWin(board, HUMAN)) {
                    board[i][j] = COMPUTER;
                    return;
                }
                board[i][j] = EMPTY;
            }
    
    // Take center or corners
    if (board[1][1] == EMPTY) board[1][1] = COMPUTER;
    else {
        vector<pair<int, int>> corners = {{0,0}, {0,2}, {2,0}, {2,2}};
        for (const auto& corner : corners)
            if (board[corner.first][corner.second] == EMPTY) {
                board[corner.first][corner.second] = COMPUTER;
                return;
            }
        
        // Take any available spot
        for (int i = 0; i < BOARD_SIZE; ++i)
            for (int j = 0; j < BOARD_SIZE; ++j)
                if (board[i][j] == EMPTY) {
                    board[i][j] = COMPUTER;
                    return;
                }
    }
}